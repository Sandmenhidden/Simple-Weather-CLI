# Simple Weather CLI

A basic Python command-line app that fetches and displays current weather data for any city using the OpenWeatherMap API.

## Features

- Get real-time weather by city name
- CLI-based and lightweight
- Easy to modify and expand

## Requirements

- Python 3.7+
- `requests` library
- OpenWeatherMap API key

## Usage

```bash
python weather.py London
```

