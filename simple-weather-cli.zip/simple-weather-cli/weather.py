import sys
import requests

API_KEY = "your_api_key_here"  # Replace with your OpenWeatherMap API key
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

def get_weather(city):
    params = {"q": city, "appid": API_KEY, "units": "metric"}
    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        data = response.json()
        print(f"🌤 {data['name']}: {data['main']['temp']}°C, {data['weather'][0]['description'].title()}")
    else:
        print("City not found or API error.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python weather.py <city>")
    else:
        get_weather(sys.argv[1])
